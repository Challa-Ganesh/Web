from django import forms
from django.contrib.auth.forms import UserCreationForm
from UserManager.models import User

class ParticipantRegForm(UserCreationForm):
    event_type = forms.ChoiceField(choices=[('online', 'Online'), ('offline', 'Offline')], widget=forms.RadioSelect)
    class Meta:
        model = User
        fields = ('fname', 'lname', 'clg', 'stream', 'email', 'event_type', 'contect_no')

    def save(self, commit=True):
        user = super(ParticipantRegForm, self).save(commit=False)
        user.is_participant = True
        if commit:
            user.save()
        return user
