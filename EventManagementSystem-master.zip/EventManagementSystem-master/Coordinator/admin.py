from django.contrib import admin
import Coordinator
from Coordinator.models import *

# Register your models here.
admin.site.register(Coordinator)